package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Emp2Dao extends JpaRepository<Emp2, Integer> {

}
